package com.nathanw.somnicue;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

final class SessionConfig {
    static final String PREFS = "somnicue_config";

    String mode = "DEEP";
    boolean dryRun = false;
    float cueGain = 0.04f;
    int deepStartMin = 25;
    int deepEndMin = 180;
    int remStartMin = 255;
    int sessionEndMin = 510;
    int deepStableMin = 8;
    int remStableMin = 3;
    int deepCueIntervalSec = 15;
    int deepCuesPerBlock = 8;
    int maxDeepBlocks = 2;
    int lucidCueIntervalSec = 90;
    int maxLucidCues = 3;

    static SessionConfig fromJson(String json) {
        SessionConfig config = new SessionConfig();
        try {
            JSONObject object = new JSONObject(json);
            config.mode = sanitizeMode(object.optString("mode", config.mode));
            config.dryRun = object.optBoolean("dryRun", false);
            config.cueGain = clampFloat(
                    (float) object.optDouble("cueGain", config.cueGain), 0.005f, 0.20f);
            int deepStartMin = config.dryRun ? 1 : 10;
            int deepEndMin = config.dryRun ? 2 : 60;
            int remStartMin = config.dryRun ? 3 : 180;
            int sessionEndMin = config.dryRun ? 5 : 240;
            int stableMin = config.dryRun ? 1 : 3;
            config.deepStartMin = clampInt(object.optInt("deepStartMin", config.deepStartMin), deepStartMin, 120);
            config.deepEndMin = clampInt(object.optInt("deepEndMin", config.deepEndMin), deepEndMin, 300);
            config.remStartMin = clampInt(object.optInt("remStartMin", config.remStartMin), remStartMin, 420);
            config.sessionEndMin = clampInt(object.optInt("sessionEndMin", config.sessionEndMin), sessionEndMin, 720);
            config.deepStableMin = clampInt(object.optInt("deepStableMin", config.deepStableMin), stableMin, 20);
            config.remStableMin = clampInt(object.optInt("remStableMin", config.remStableMin), 1, 10);
            config.deepCueIntervalSec = clampInt(
                    object.optInt("deepCueIntervalSec", config.deepCueIntervalSec), 10, 60);
            config.deepCuesPerBlock = clampInt(
                    object.optInt("deepCuesPerBlock", config.deepCuesPerBlock), 1, 20);
            config.maxDeepBlocks = clampInt(
                    object.optInt("maxDeepBlocks", config.maxDeepBlocks), 0, 6);
            config.lucidCueIntervalSec = clampInt(
                    object.optInt("lucidCueIntervalSec", config.lucidCueIntervalSec), 45, 600);
            config.maxLucidCues = clampInt(
                    object.optInt("maxLucidCues", config.maxLucidCues), 0, 10);
        } catch (Exception ignored) {
            // Invalid fields retain conservative defaults.
        }
        if (config.deepEndMin <= config.deepStartMin) {
            config.deepEndMin = config.deepStartMin + 60;
        }
        if (config.sessionEndMin <= config.remStartMin) {
            config.sessionEndMin = config.remStartMin + 120;
        }
        return config;
    }

    static SessionConfig load(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SessionConfig c = new SessionConfig();
        c.mode = sanitizeMode(p.getString("mode", c.mode));
        c.dryRun = p.getBoolean("dryRun", c.dryRun);
        c.cueGain = p.getFloat("cueGain", c.cueGain);
        c.deepStartMin = p.getInt("deepStartMin", c.deepStartMin);
        c.deepEndMin = p.getInt("deepEndMin", c.deepEndMin);
        c.remStartMin = p.getInt("remStartMin", c.remStartMin);
        c.sessionEndMin = p.getInt("sessionEndMin", c.sessionEndMin);
        c.deepStableMin = p.getInt("deepStableMin", c.deepStableMin);
        c.remStableMin = p.getInt("remStableMin", c.remStableMin);
        c.deepCueIntervalSec = p.getInt("deepCueIntervalSec", c.deepCueIntervalSec);
        c.deepCuesPerBlock = p.getInt("deepCuesPerBlock", c.deepCuesPerBlock);
        c.maxDeepBlocks = p.getInt("maxDeepBlocks", c.maxDeepBlocks);
        c.lucidCueIntervalSec = p.getInt("lucidCueIntervalSec", c.lucidCueIntervalSec);
        c.maxLucidCues = p.getInt("maxLucidCues", c.maxLucidCues);
        return c;
    }

    void save(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString("mode", mode)
                .putBoolean("dryRun", dryRun)
                .putFloat("cueGain", cueGain)
                .putInt("deepStartMin", deepStartMin)
                .putInt("deepEndMin", deepEndMin)
                .putInt("remStartMin", remStartMin)
                .putInt("sessionEndMin", sessionEndMin)
                .putInt("deepStableMin", deepStableMin)
                .putInt("remStableMin", remStableMin)
                .putInt("deepCueIntervalSec", deepCueIntervalSec)
                .putInt("deepCuesPerBlock", deepCuesPerBlock)
                .putInt("maxDeepBlocks", maxDeepBlocks)
                .putInt("lucidCueIntervalSec", lucidCueIntervalSec)
                .putInt("maxLucidCues", maxLucidCues)
                .apply();
    }

    boolean usesDeepCues() {
        return "DEEP".equals(mode) || "COMBINED".equals(mode);
    }

    boolean usesLucidCues() {
        return "LUCID".equals(mode) || "COMBINED".equals(mode);
    }

    private static String sanitizeMode(String input) {
        if ("SENSOR_ONLY".equals(input)
                || "DEEP".equals(input)
                || "LUCID".equals(input)
                || "COMBINED".equals(input)) {
            return input;
        }
        return "DEEP";
    }

    private static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float clampFloat(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
