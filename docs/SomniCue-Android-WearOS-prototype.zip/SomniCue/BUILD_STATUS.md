# Build and validation status

Generated: 2026-07-18

## Completed in the generation environment

- Parsed all 9 Java source files with a Java syntax parser.
- Parsed all 6 XML files for well-formedness.
- Verified that the phone and watch modules use the same application ID and identical Data Layer paths.
- Verified the deep-cue source constants: 50 ms bursts, 5 ms tapers, and 1.075-second second-burst onset.
- Verified the accelerated dry-run and real-night timing constants.
- Syntax-checked the POSIX shell build scripts.

## Not completed in the generation environment

No Android SDK, ADB installation, Gradle dependency cache, Galaxy S23+, or Galaxy Watch Ultra was attached to this environment. Consequently:

- no APK is included;
- the Gradle project has not yet completed a real Android compile;
- runtime permission behavior, overnight sensor continuity, Data Layer delivery, battery use, and acoustic output must be validated on the target devices.

The first decisive check is to open the project in a compatible Android Studio installation or run `build-local.sh` / `build-local.ps1`, then complete the eight-minute dry run in `TONIGHT_CHECKLIST.md`.
