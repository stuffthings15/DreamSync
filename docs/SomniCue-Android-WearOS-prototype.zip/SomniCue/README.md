# SomniCue — S23 + Galaxy Watch Ultra research prototype

SomniCue is a two-module Android Studio project:

- **`phone`** runs on the Galaxy S23+. It stays armed as a low-volume audio engine, plays cues, opens the watch companion app, and sends configuration over the Wear OS Data Layer.
- **`wear`** runs on the Galaxy Watch Ultra. It samples accelerometer and heart-rate data in an overnight foreground service, estimates **probable** quiet sleep / NREM / REM windows, gates cues conservatively, adapts cue gain after likely arousals, and writes a CSV log.

This is an **experimental general-wellness prototype**, not a medical device, EEG system, diagnostic sleep-stage monitor, or treatment for insomnia or any other sleep disorder.

## What the research supports—and what this build can actually do

The Besedovsky/Ngo/Born laboratory protocol used frontal EEG to detect a cortical slow oscillation and place two 50 ms pink-noise bursts on the succeeding upstate, with the bursts 1.075 seconds apart. The watch cannot measure cortical EEG, so SomniCue does **not** claim phase-locked slow-oscillation stimulation. It borrows the sound envelope but performs **wrist-stage-gated cueing**: cues are allowed only during a stable, low-motion, low-heart-rate early-night window.

The MIT SleepStim work provides the closer systems precedent: a consumer watch estimates sleep state from motion and heart physiology and a phone delivers sensory cues. SomniCue follows that architecture, but starts with a transparent heuristic rather than a trained classifier so it can be inspected and tested immediately.

For lucid dreaming, SomniCue implements a minimal targeted-lucidity-reactivation pattern: the user pairs a distinct chime with a reality-check mindset while awake; the same chime is replayed sparingly during a later probable-REM window. It does not guarantee dream recall or lucidity.

## Conservative default protocol

### Early-night NREM mode

1. No cues for the first 25 minutes.
2. Estimate a personal waking/resting heart-rate baseline from the early session.
3. Require at least eight continuous minutes of a probable-NREM state.
4. Play one **pair** of 50 ms pink-noise bursts; the two bursts are 1.075 seconds apart.
5. Wait 15 seconds before another pair.
6. Stop after eight pairs (about two minutes) and back off for at least 15 minutes.
7. Allow at most two blocks in the first three hours.
8. Stop immediately on movement/heart-rate arousal evidence.

This is intentionally much less aggressive than the laboratory stimulus count because it is not EEG phase locked.

### Lucid mode

1. Before bed, tap **Practice lucid cue** 10 times.
2. Each time the chime plays, ask “Am I dreaming?”, inspect a clock/text twice, and visualize recognizing a dream.
3. During the night, no lucid cues are allowed until 255 minutes after the session begins.
4. The watch requires three stable minutes of a probable-REM state.
5. The phone plays the paired chime no more often than every 90 seconds and no more than three times total.
6. Any likely arousal causes a ten-minute backoff and a 30% cue-gain reduction when the arousal occurred within 20 seconds of a cue.

### Combined mode

NREM cues are restricted to the first three hours. Lucid cues do not begin until after 4 hours 15 minutes, so the two goals do not compete in the same window.

## Source layout

```text
SomniCue/
├── phone/
│   └── src/main/java/com/nathanw/somnicue/
│       ├── MainActivity.java           # setup, remote watch launch, config
│       ├── CuePlaybackService.java     # phone foreground audio engine
│       ├── PhoneDataListenerService.java # receives watch summaries
│       └── Protocol.java
├── wear/
│   └── src/main/java/com/nathanw/somnicue/
│       ├── MainActivity.java           # permissions + visible start/stop
│       ├── SleepSessionService.java    # sensing, gating, adaptation, CSV
│       ├── WearCommandListenerService.java
│       ├── SessionConfig.java
│       └── Protocol.java
├── IMPLEMENTATION_PLAN.md
├── TONIGHT_CHECKLIST.md
└── BUILD_STATUS.md
```

Both APKs use the same package name and, when built from this project, the same signing key. That is required for authenticated Wear OS Data Layer communication.

## Build prerequisites

- Android Studio compatible with Android Gradle Plugin 9.2
- Android SDK 36 installed
- JDK 17 selected for Gradle
- Galaxy S23+ with USB debugging enabled
- Galaxy Watch Ultra with Developer options, ADB debugging, and Wireless debugging enabled

The repository specifies Gradle 9.4.1. A binary Gradle wrapper JAR is not bundled, but two bootstrap build scripts are included:

```bash
# macOS / Linux
./build-local.sh

# Windows PowerShell
.\build-local.ps1
```

The scripts use an installed Gradle when available; otherwise they download the official Gradle 9.4.1 distribution and build both debug APKs. Android Studio can also use its configured local Gradle distribution.

The source was statically checked for Java syntax and XML well-formedness in the generation environment. It was not compiled there because that environment had no Android SDK or dependency cache; the first real build on your development computer remains the decisive check.

## Install on the two devices

### 1. Connect the phone

Enable Developer options and USB debugging on the S23+, connect it by USB, and accept the computer authorization prompt.

### 2. Connect the watch wirelessly

On the watch:

1. Open **Settings → About watch → Software information**.
2. Tap **Software version** repeatedly until Developer options are enabled.
3. Open **Settings → Developer options**.
4. Enable **ADB debugging** and **Wireless debugging**.
5. Choose **Pair new device** and note the pairing IP/port and code.

On the development computer:

```bash
adb pair WATCH_IP:PAIR_PORT
adb connect WATCH_IP:DEBUG_PORT
adb devices
```

The pairing port and debugging port are often different; use the values shown on the watch.

### 3. Build and install

In Android Studio, create/select two run configurations:

- Run module **`phone`** on the S23+.
- Run module **`wear`** on the Galaxy Watch Ultra.

Or build debug APKs with the included pinned-Gradle script, then install explicitly:

```bash
# macOS / Linux
./build-local.sh

# After the build
adb -s PHONE_SERIAL install -r phone/build/outputs/apk/debug/phone-debug.apk
adb -s WATCH_SERIAL install -r wear/build/outputs/apk/debug/wear-debug.apk
```

On Windows PowerShell, run `./build-local.ps1` instead. A conventional `gradlew` can be generated later with `./bootstrap-gradle.sh` when Gradle 9.4.1 is already installed.

## Eight-minute accelerated dry run before bed

1. Open SomniCue on the S23+.
2. Select **Combined** or **Early-night probable-NREM cues**.
3. Check **8-minute accelerated dry-run timing**.
4. Set phone media volume low. Start with app cue gain at 2–4%.
5. Tap **Test deep cue** and confirm two very soft bursts.
6. Tap **Practice lucid cue** and confirm the two-tone chime.
7. Tap **Arm phone audio + send settings**.
8. Tap **Open SomniCue on watch**.
9. On the watch, grant **Activity recognition**. For heart rate, grant **Sensors/Heart rate**; on Wear OS 4–5.1, choose **Allow all the time** when the separate background prompt appears.
10. Tap **Start night session** while the watch activity is visible. If all-time heart-rate access is unavailable or denied, SomniCue starts a conservative motion-only fallback rather than blocking the session.
11. Lie still for several minutes. The watch should eventually issue a cue if the heuristic sees a stable quiet state.
12. Stop the dry run, return to the phone, **uncheck dry run**, resend settings, and restart the watch session for the actual night.

Do not fall asleep with dry-run timing enabled; it deliberately compresses all windows.

## Tonight’s recommended test

1. Charge the watch above 60%; disable watch battery saver for the test.
2. Wear it snugly enough for continuous heart-rate readings without restricting circulation.
3. Put the S23+ on a charger 50–100 cm from the pillow, with its speaker unobstructed.
4. Ensure media is routed to the phone speaker—not earbuds, a car, TV, or Bluetooth speaker.
5. Calibrate the cue while awake until it is **barely audible**, then reduce either the app gain or media volume one step.
6. For the first real night, use **Deep** rather than Combined if sleep quality is the main goal. Combined is available, but it makes it harder to identify which module caused an awakening.
7. Arm phone audio, send settings, open the watch app, and tap Start on the watch.
8. Turn both screens off. Keep the phone foreground-service notification and watch session notification active.
9. In the morning, stop the watch session before opening other apps. The watch sends a summary and the phone audio service automatically disarms when that summary arrives.
10. Record: estimated sleep quality (1–10), number of remembered awakenings, whether any cue was noticed, dream recall (0–3), and lucid dream yes/no.

## Logs

The watch writes a row every five seconds with:

- elapsed time
- heart-rate median over two minutes
- estimated baseline heart rate
- 30-second motion RMS
- heart-rate variability proxy (standard deviation of BPM, **not clinical HRV**)
- NREM and REM heuristic scores
- state label
- cue/arousal events
- adaptive gain

The file is stored at:

```text
/sdcard/Android/data/com.nathanw.somnicue/files/sessions/
```

Pull it with ADB:

```bash
adb -s WATCH_SERIAL shell ls /sdcard/Android/data/com.nathanw.somnicue/files/sessions/
adb -s WATCH_SERIAL pull /sdcard/Android/data/com.nathanw.somnicue/files/sessions/ ./somnicue-sessions/
```

The phone also receives a short JSON summary when the watch stops. Receipt of that summary automatically stops the phone audio foreground service.

## Safety boundaries

- Do not use the prototype to diagnose or treat a sleep disorder.
- Do not increase volume in an attempt to reproduce “50 dB”; phone gain is not an SPL measurement and varies by speaker, distance, room, case, and media-volume setting.
- Prefer the phone speaker or a purpose-built low-volume pillow speaker. Do not block alarms or sleep in uncomfortable in-ear hardware.
- Stop the experiment if cues repeatedly wake you, produce headaches, worsen nightmares, increase daytime sleepiness, or reduce sleep quality.
- Do not run unsupervised stimulation if you have suspected/untreated sleep apnea, seizure disorder, severe insomnia, dream-enactment behavior, a serious cardiac rhythm condition, bipolar mania/psychosis vulnerability, or another condition for which sleep disruption may be consequential; discuss the experiment with a clinician first.
- Never trade sleep duration for lucid-dream attempts. Do not drive or perform hazardous work if the trial leaves you sleepy.

## Known technical limitations

1. **No EEG:** the watch cannot identify the ~0.9 Hz cortical slow-oscillation phase used in the laboratory paper.
2. **Heuristic staging:** wrist motion and heart rate can gate broad windows, but they cannot reliably distinguish N2, N3, REM, and quiet wake on every person or every night.
3. **Data Layer latency:** watch-to-phone messaging has variable latency. This is acceptable for stage gating, not for millisecond-scale phase locking. The phone generates both pink-noise bursts locally after one message so the 1.075-second spacing is deterministic on one device.
4. **Uncalibrated sound level:** the app controls digital amplitude, not acoustic SPL.
5. **Heart-rate permission variability:** all-time/background sensor access differs by Wear OS version and may be declined. The prototype continues in motion-only mode, which is less selective and intentionally conservative.
6. **Battery/firmware variability:** Samsung firmware, sensor duty cycling, permissions, and battery policy can change overnight behavior.
7. **No clinical validation:** the cue rules and thresholds require empirical personalization and validation.

## Development roadmap

See `IMPLEMENTATION_PLAN.md` for the full research and engineering roadmap, including Samsung raw-sensor integration, a trained probability model, sham-controlled N-of-1 testing, and an optional EEG pathway for genuine slow-oscillation phase locking.
