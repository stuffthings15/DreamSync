# Notice

This starter project was written as a new implementation. It does not copy source code from `nathanww/BioData` or MIT SleepStim repositories. Those projects informed the architecture and research direction.

The generated pink-noise filter coefficients in `CuePlaybackService.java` are a conventional public-domain-style implementation pattern for approximate pink-noise synthesis; verify licensing and acoustic behavior before distributing a product.
