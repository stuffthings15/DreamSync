# Research and platform sources

Accessed 2026-07-18.

## Sleep stimulation and wearable systems

- Besedovsky L, Ngo H-VV, Dimitrov S, et al. **Auditory closed-loop stimulation of EEG slow oscillations strengthens sleep and signs of its immune-supportive function.** *Nature Communications*. 2017;8:1984. https://doi.org/10.1038/s41467-017-02170-3
- MIT Media Lab. **SleepStim.** https://www.media.mit.edu/projects/sleepstim/overview/
- Whitmore NW, Harris JC, Kovach T, Paller KA. **Improving memory via automated targeted memory reactivation during sleep.** *Journal of Sleep Research*. 2023;32:e13731. https://pubmed.ncbi.nlm.nih.gov/36129154/
- Nathan W. Whitmore. Research overview. https://nathanww.github.io/
- Nathan Whitmore. **BioData** Android/Wear OS repository. https://github.com/nathanww/BioData
- Nathan Whitmore. **home-tmr** smartphone/smartwatch TMR repository. https://github.com/nathanww/home-tmr

## Lucid dreaming

- Konkoly KR, Whitmore NW, Mallett R, Mazurek CY, Paller KA. **Provoking lucid dreams at home with sensory cues paired with pre-sleep cognitive training.** *Consciousness and Cognition*. 2024;125:103759. https://doi.org/10.1016/j.concog.2024.103759

## Android and Samsung implementation

- Android Developers. **Overview of Data Layer API.** https://developer.android.com/training/wearables/data/overview
- Android Developers. **Declare appropriate permissions for Health Services on Wear OS.** https://developer.android.com/health-and-fitness/health-services/permissions
- Android Developers. **Debug a Wear OS app over Wi-Fi.** https://developer.android.com/training/wearables/apps/debugging
- Samsung Developer. **Samsung Health Sensor SDK.** https://developer.samsung.com/health/sensor/overview.html

## Consumer sleep technology boundary

- American Academy of Sleep Medicine. **Consumer Sleep Technology: An AASM Position Statement.** https://aasm.org/advocacy/position-statements/consumer-sleep-technology/
