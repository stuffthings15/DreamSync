#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
GRADLE_VERSION=9.4.1
GRADLE_SHA256=2ab2958f2a1e51120c326cad6f385153bb11ee93b3c216c5fccebfdfbb7ec6cb
TOOLS_DIR="$ROOT/.tools"
GRADLE_HOME="$TOOLS_DIR/gradle-$GRADLE_VERSION"
ZIP="$TOOLS_DIR/gradle-$GRADLE_VERSION-bin.zip"
GRADLE=""

if command -v gradle >/dev/null 2>&1; then
  INSTALLED_VERSION=$(gradle --version 2>/dev/null | awk '/^Gradle / { print $2; exit }')
  if [ "$INSTALLED_VERSION" = "$GRADLE_VERSION" ]; then
    GRADLE=gradle
  else
    echo "Installed Gradle is ${INSTALLED_VERSION:-unknown}; using pinned Gradle $GRADLE_VERSION instead."
  fi
fi

if [ -z "$GRADLE" ]; then
  mkdir -p "$TOOLS_DIR"
  if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
    echo "Gradle $GRADLE_VERSION was not found; downloading the official distribution..."
    if command -v curl >/dev/null 2>&1; then
      curl -fL --retry 3 -o "$ZIP" \
        "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
    elif command -v wget >/dev/null 2>&1; then
      wget -O "$ZIP" \
        "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
    else
      echo "Install curl or wget, or install Gradle $GRADLE_VERSION manually." >&2
      exit 1
    fi
    if command -v sha256sum >/dev/null 2>&1; then
      ACTUAL_SHA256=$(sha256sum "$ZIP" | awk '{print $1}')
    elif command -v shasum >/dev/null 2>&1; then
      ACTUAL_SHA256=$(shasum -a 256 "$ZIP" | awk '{print $1}')
    else
      echo "Install sha256sum or shasum so the Gradle download can be verified." >&2
      exit 1
    fi
    if [ "$ACTUAL_SHA256" != "$GRADLE_SHA256" ]; then
      echo "Gradle archive checksum mismatch; refusing to execute it." >&2
      rm -f "$ZIP"
      exit 1
    fi
    if ! command -v unzip >/dev/null 2>&1; then
      echo "The unzip command is required to unpack Gradle." >&2
      exit 1
    fi
    rm -rf "$GRADLE_HOME"
    unzip -q "$ZIP" -d "$TOOLS_DIR"
  fi
  GRADLE="$GRADLE_HOME/bin/gradle"
fi

if [ -z "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" ] && [ ! -f "$ROOT/local.properties" ]; then
  cat >&2 <<'MSG'
Android SDK location was not found.
Either:
  1. open the project once in Android Studio, or
  2. set ANDROID_SDK_ROOT, or
  3. create local.properties with: sdk.dir=/absolute/path/to/Android/Sdk
MSG
  exit 1
fi

cd "$ROOT"
"$GRADLE" --no-daemon :phone:assembleDebug :wear:assembleDebug

echo
echo "Built APKs:"
echo "  $ROOT/phone/build/outputs/apk/debug/phone-debug.apk"
echo "  $ROOT/wear/build/outputs/apk/debug/wear-debug.apk"
