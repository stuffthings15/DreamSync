$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$GradleVersion = "9.4.1"
$GradleSha256 = "2ab2958f2a1e51120c326cad6f385153bb11ee93b3c216c5fccebfdfbb7ec6cb"
$ToolsDir = Join-Path $Root ".tools"
$GradleHome = Join-Path $ToolsDir "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome "bin\gradle.bat"
$Zip = Join-Path $ToolsDir "gradle-$GradleVersion-bin.zip"
$Gradle = $null

$SystemGradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($SystemGradle) {
    $VersionLine = (& $SystemGradle.Source --version | Select-String '^Gradle ' | Select-Object -First 1).Line
    $InstalledVersion = if ($VersionLine) { ($VersionLine -split '\s+')[1] } else { "unknown" }
    if ($InstalledVersion -eq $GradleVersion) {
        $Gradle = $SystemGradle.Source
    } else {
        Write-Host "Installed Gradle is $InstalledVersion; using pinned Gradle $GradleVersion instead."
    }
}

if (-not $Gradle) {
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null
    if (-not (Test-Path $GradleExe)) {
        Write-Host "Gradle $GradleVersion was not found; downloading the official distribution..."
        Invoke-WebRequest `
            -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" `
            -OutFile $Zip
        $ActualSha256 = (Get-FileHash -Algorithm SHA256 -Path $Zip).Hash.ToLowerInvariant()
        if ($ActualSha256 -ne $GradleSha256) {
            Remove-Item -Force $Zip
            throw "Gradle archive checksum mismatch; refusing to execute it."
        }
        if (Test-Path $GradleHome) { Remove-Item -Recurse -Force $GradleHome }
        Expand-Archive -Path $Zip -DestinationPath $ToolsDir -Force
    }
    $Gradle = $GradleExe
}

$SdkFromEnvironment = $env:ANDROID_SDK_ROOT
if (-not $SdkFromEnvironment) { $SdkFromEnvironment = $env:ANDROID_HOME }
$LocalProperties = Join-Path $Root "local.properties"
if (-not $SdkFromEnvironment -and -not (Test-Path $LocalProperties)) {
    throw @"
Android SDK location was not found.
Open the project once in Android Studio, set ANDROID_SDK_ROOT, or create
local.properties with: sdk.dir=C:\\Users\\YOU\\AppData\\Local\\Android\\Sdk
"@
}

Push-Location $Root
try {
    & $Gradle --no-daemon :phone:assembleDebug :wear:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE" }
} finally {
    Pop-Location
}

Write-Host ""
Write-Host "Built APKs:"
Write-Host "  $Root\phone\build\outputs\apk\debug\phone-debug.apk"
Write-Host "  $Root\wear\build\outputs\apk\debug\wear-debug.apk"
