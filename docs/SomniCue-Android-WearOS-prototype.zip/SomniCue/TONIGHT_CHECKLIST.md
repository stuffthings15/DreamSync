# SomniCue tonight checklist

## Before installing

- [ ] Android Studio has Android SDK 36 and JDK 17.
- [ ] S23+ USB debugging is enabled.
- [ ] Watch Ultra Developer options, ADB debugging, and Wireless debugging are enabled.
- [ ] Phone and watch are paired normally in Galaxy Wearable and are online.

## Install

- [ ] Run the `phone` module on the S23+.
- [ ] Run the `wear` module on the Watch Ultra.
- [ ] Confirm both installs came from the same Android Studio project/signing key.

## Eight-minute accelerated dry run

- [ ] Open phone app; select **Deep** for the first test.
- [ ] Enable **8-minute accelerated dry-run timing**.
- [ ] Put phone media volume low and app cue gain at 2–4%.
- [ ] Test the deep cue; it should be two very soft bursts.
- [ ] Test/practice the lucid cue; it should be a fixed two-tone chime.
- [ ] Tap **Arm phone audio + send settings**.
- [ ] On the watch, grant **Activity recognition** and **Sensors/Heart rate**.
- [ ] On Wear OS 4–5.1, answer the separate sensor prompt with **Allow all the time** for overnight heart rate.
- [ ] If all-time heart rate is denied or unavailable, verify the watch reports **motion-only fallback**; the dry run can still proceed, but staging will be less selective.
- [ ] Start the watch session while the watch activity is visible.
- [ ] Lie still long enough to confirm at least one cue and a running notification.
- [ ] Stop the dry run.

## Real night

- [ ] Disable dry-run timing, resend settings, and restart the watch session.
- [ ] Use **Deep** only for night 1; use Sensor-only on a nearby night as a baseline.
- [ ] Charge phone; watch battery at least 60%; watch battery saver off.
- [ ] Put phone 50–100 cm from pillow with speaker unobstructed.
- [ ] Ensure audio is routed to phone speaker, not Bluetooth.
- [ ] Make cues barely audible while awake, then reduce one step.
- [ ] Keep normal alarm functionality intact.

## Morning record

- [ ] Sleep quality 1–10
- [ ] Restedness 1–10
- [ ] Remembered awakenings
- [ ] Cue noticed: no / unsure / yes
- [ ] Dream recall 0–3
- [ ] Lucid dream: no / unsure / yes
- [ ] Headache, nightmare, unusual anxiety, or daytime sleepiness
- [ ] Confirm the watch summary reached the phone and the phone audio notification disappeared automatically
- [ ] Pull the watch CSV log before uninstalling the app
