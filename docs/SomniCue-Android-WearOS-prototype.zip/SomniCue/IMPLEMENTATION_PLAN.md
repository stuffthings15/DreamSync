# Comprehensive implementation plan

## 1. Product definition

Build a general-wellness research system with two distinct interventions:

1. **Early-night slow-wave support:** deliver low-intensity auditory cue pairs only when wrist physiology indicates stable probable NREM sleep.
2. **Late-night targeted lucidity reactivation:** pair a unique cue with a lucid-dream mindset before sleep, then replay it sparingly in probable REM.

Keep the intervention names precise. Until EEG is added, use “stage-gated auditory cueing,” not “closed-loop slow-oscillation stimulation.”

## 2. Evidence translation

### EEG slow-oscillation study

The laboratory implementation used:

- frontal EEG
- 0.25–4 Hz online filtering
- adaptive negative-peak detection
- an individualized delay to the positive upstate
- two 50 ms pink-noise bursts
- 1.075 s between burst onsets
- a 2.5 s detection pause
- stimulation only in N2/SWS and not during arousal
- 120 minutes of stimulation

The study reported increased slow-oscillation power and amplitude during stimulation. It did not report an increase in total minutes of slow-wave sleep. Therefore, the app should not use watch-reported “deep sleep minutes” as its sole success criterion.

### MIT SleepStim systems pattern

The relevant systems pattern is:

```text
watch physiology → real-time state probability → cue-control policy → phone stimulus → arousal feedback
```

The watch/phone architecture is suitable for broad sleep-stage gating. It is not suitable for EEG phase locking because phone/watch transport and audio latency are not deterministic at the sub-second phase level.

### Lucid-dream targeted reactivation

The lucid module requires both halves of the procedure:

1. **Wake pairing:** repeated cue + reality check + intention + visualization.
2. **Sleep replay:** the identical cue during a high-confidence probable-REM window.

Playing arbitrary sounds in REM without the wake association is not the same intervention.

## 3. System architecture

```text
Galaxy Watch Ultra
  ├─ accelerometer (5 Hz requested)
  ├─ standard heart-rate sensor (~device-controlled rate)
  ├─ overnight foreground health service
  ├─ rolling features and state machine
  ├─ cue budget / backoff / adaptive gain
  └─ CSV logger
          │ Wear OS Data Layer message
          ▼
Galaxy S23+
  ├─ foreground media-playback service
  ├─ deterministic local cue waveform generation
  ├─ media speaker output
  ├─ setup and calibration UI
  └─ summary display
```

Use the same package name and signing certificate on phone and watch. Keep separate APK modules and include `android.hardware.type.watch` only in the wear manifest. The watch requests foreground activity/heart-rate access first and background heart-rate access separately. If all-time heart rate is unavailable or declined, the session continues with accelerometer features and conservative time-of-night priors rather than failing closed.

## 4. Version-0 classifier

### Rolling inputs

- 10-second and 30-second dynamic-acceleration RMS
- two-minute heart-rate median
- two-minute BPM standard deviation
- two-minute heart-rate slope
- personal baseline estimated from the first 5–10 minutes
- elapsed time since the user started the night session
- early-night and late-night priors

### Outputs

- `SETTLING`
- `AWAKE_OR_MOVING`
- `QUIET_SLEEP`
- `PROBABLE_NREM`
- `PROBABLE_REM`
- `AROUSAL`
- `UNKNOWN`

These are control states, not AASM-scored sleep stages.

### Cue eligibility

A cue requires all of the following:

- required intervention mode is active
- intervention time window is open
- state confidence threshold is met
- state has remained stable for the configured duration
- no recent arousal/backoff
- cue budget remains
- phone node is connected, or the cue attempt is logged as undelivered

### Arousal adaptation

If movement or a rapid heart-rate rise occurs within 20 seconds after a cue:

- stop any active cue block
- reduce digital cue gain by 30%
- back off for 10 minutes
- disable all further cues after three cue-linked arousals

This is the most important safety-control loop in the first build.

## 5. Version-1 learned model

After collecting at least 10–20 nights per user, replace fixed thresholds with a calibrated model.

### Epoching

- produce features every 10 seconds
- use a 30-second current epoch
- add 4–5 minutes of temporal context
- retain time-since-sleep-onset/circadian priors

### Features

Accelerometer:

- vector magnitude activity counts
- RMS and median absolute deviation
- jerk
- orientation changes
- zero crossings
- spectral power in low-frequency bands
- movement-burst count

Cardiac:

- median BPM
- BPM trend
- robust variation
- IBI RMSSD and pNN50 when reliable IBI is available
- missingness and sensor-quality flags

Context:

- elapsed night time
- recent state probabilities
- previous arousal/cue events
- user-specific baseline and variance

### Model candidates

Start with an interpretable gradient-boosted model or two-layer MLP. Then compare against a small temporal convolutional network or GRU converted to TensorFlow Lite. Output calibrated probabilities for wake/quiet-NREM/REM rather than a hard stage.

### Cue thresholds

Example production policy:

- NREM cue: mean `P(NREM) > 0.85` for 6–8 minutes, `P(wake) < 0.10`
- REM cue: mean `P(REM) > 0.75` for 2–3 minutes, `P(wake) < 0.12`
- never cue if the signal-quality probability is below threshold

Tune thresholds for precision rather than recall. Missing an opportunity is preferable to waking the user.

## 6. Samsung Health Sensor SDK option

Add an optional `samsungRaw` product flavor for the Galaxy Watch Ultra.

Potential additions:

- raw/processed PPG
- IBI
- higher-quality accelerometer streams
- sensor-quality metrics
- skin temperature or SpO2 only where the SDK/device explicitly supports the needed access and permissions

For local development, enable Samsung Health Sensor SDK developer mode. For distribution, follow Samsung’s package/signature registration requirements. Keep the standard Android SensorManager implementation as a fallback so the app remains testable without partner approval.

## 7. Audio subsystem

### Deep cue

- sample rate: 44.1 kHz
- mono floating-point PCM
- 50 ms pink-noise burst
- 5 ms rise/fall taper
- second burst onset at 1.075 seconds
- one Data Layer command triggers the entire local waveform

### Lucid cue

- stable, distinctive, nonverbal two-tone chime
- same PCM waveform used for waking practice and sleep replay
- no randomization of the cue identity within an experiment block

### Calibration

Digital gain must never be labeled in dB SPL. Store:

- Android media-volume step
- app gain
- phone model
- phone placement/distance
- whether a case or pillow speaker was used

For a real study, calibrate with an SPL meter at the pillow and save the measured level.

## 8. Experimental design

### Stage 1 — engineering validation (1–3 nights)

Primary questions:

- Did both foreground services survive the night?
- What percentage of the night had usable heart rate?
- Were watch-to-phone messages delivered?
- Did the cue pair spacing remain correct?
- How much battery was consumed?
- Did any cue clearly wake the user?

Do not interpret sleep benefit yet.

### Stage 2 — tolerance and personalization (4–10 nights)

Alternate sensor-only and low-cue nights. Adjust only one parameter at a time:

- cue gain
- stable-state duration
- cue interval
- number of cues per block

Freeze parameters once a tolerable configuration is found.

### Stage 3 — blinded N-of-1 trial (12–20 nights)

Randomize nights to active or sham, with the phone/wear UI hiding condition until morning. Sham nights run identical staging and logging but suppress audio.

Predefine outcomes:

Primary:

- morning sleep quality, 1–10
- restedness, 1–10
- lucid dream occurrence, yes/no

Secondary:

- remembered awakenings
- cue noticed, yes/no
- dream recall, 0–3
- cue-linked arousal rate
- Samsung Health sleep metrics used only as secondary consumer estimates

Analyze within-person differences and report uncertainty. Do not cherry-pick nights.

## 9. Genuine EEG closed loop — future hardware path

To reproduce the core laboratory mechanism, add a frontal EEG device or headband.

Required real-time pipeline:

1. sample EEG at ≥200 Hz
2. band-pass approximately 0.25–4 Hz
3. detect adaptive negative slow-oscillation peaks
4. estimate each user’s negative-peak-to-upstate delay
5. schedule the first 50 ms burst at the predicted upstate
6. schedule the second burst 1.075 seconds later
7. impose a refractory interval
8. halt on arousal or exit from N2/N3
9. timestamp EEG, trigger, and acoustic output on a common clock

Do not route phase-critical triggers through the Wear OS Data Layer. Detection and audio scheduling should run on one low-latency processor, or on hardware with measured and compensated end-to-end latency.

## 10. Production hardening

- Room/SQLite persistence instead of raw CSV only
- encrypted local storage and explicit export/delete controls
- Health Connect write-back only with clear user consent
- reconnect logic and phone-node health checks
- sensor-quality monitoring
- watchdog for stalled sensors
- automatic termination after a configured session maximum
- explicit UI indication of motion-only versus motion-plus-heart-rate operation
- delivery acknowledgements so cue counts distinguish attempted, delivered, and acoustically played events
- battery-use dashboard
- crash reporting that excludes raw health data
- unit tests for score calculations and cue budgets
- hardware-in-the-loop timing tests for audio onset
- regulatory and claims review before any public release

## 11. Product language

Acceptable early language:

- “research prototype”
- “stage-gated sleep cues”
- “supports personal sleep experiments”
- “probable NREM/REM window”

Avoid without clinical validation and appropriate regulatory work:

- “treats insomnia”
- “guarantees deep sleep”
- “clinically accurate sleep staging”
- “boosts immunity”
- “induces lucid dreams”
- “EEG closed loop” when only wrist physiology is used
